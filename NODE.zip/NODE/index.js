const os=require('os')
    console.log("Información de sistema operativo");
    console.log("-----------------------------------------------------------------------------------------");
    console.log("Sistema operativo : ",os.platform());
    console.log("-----------------------------------------------------------------------------------------");
    console.log("Versión de sistema operativo : ",os.release());
    console.log("-----------------------------------------------------------------------------------------");
    console.log("Arquitectura del procesador",os.arch())
    console.log("-----------------------------------------------------------------------------------------");
    console.log("Memoria libre:",os.freemem())
    console.log("-----------------------------------------------------------------------------------------");
    console.log("Memoria total:",os.totalmem())
    console.log("-----------------------------------------------------------------------------------------");
    console.log("Procesadores lógicos del dispositivo:",os.cpus())
    console.log("-----------------------------------------------------------------------------------------");

function conversionTiempo(m){
    m=os.uptime;
        Min=m/60
        Hor=m/3600
        Dia=m/86400
    return console.log(`Tiempo de uso en segundos: ${m} / tiempo de uso en minutos: ${Min} / tiempo de uso en horas: ${Hor} / tiempo de uso en días:${Dia}`)

}
    conversionTiempo()


















